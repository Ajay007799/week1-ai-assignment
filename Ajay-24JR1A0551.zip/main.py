import json
import random
from datetime import datetime

OUTPUT_FILE = "output.txt"


def save_to_file(text):
    with open(OUTPUT_FILE, "a") as file:
        file.write(text + "\n")


def load_data():
    with open("tips.json", "r") as file:
        return json.load(file)


def generate_study_tip(data):
    tip = random.choice(data["study_tips"])
    print("\nStudy Tip:")
    print(tip)
    save_to_file("Study Tip: " + tip)


def generate_motivation_quote(data):
    quote = random.choice(data["motivation_quotes"])
    print("\nMotivation Quote:")
    print(quote)
    save_to_file("Motivation Quote: " + quote)


def display_datetime():
    current_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    print("\nCurrent Date & Time:")
    print(current_time)
    save_to_file("Date & Time: " + current_time)


def main():
    print("===== Smart Student Assistant =====")

    name = input("Enter your name: ")
    greeting = f"Hello, {name}! Welcome to Smart Student Assistant."
    print(greeting)

    save_to_file("\n" + greeting)

    data = load_data()

    while True:
        print("\nMenu")
        print("1. Generate Study Tip")
        print("2. Generate Motivation Quote")
        print("3. Display Current Date & Time")
        print("4. Exit")

        choice = input("Enter your choice (1-4): ")

        if choice == "1":
            generate_study_tip(data)

        elif choice == "2":
            generate_motivation_quote(data)

        elif choice == "3":
            display_datetime()

        elif choice == "4":
            print("Thank you for using Smart Student Assistant!")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()